# FamilienEssensPlaner – Complete V5

Diese Version bündelt die gewünschten Verbesserungen in einer mobilen PWA:

- professionelle Startseite
- automatische „Günstige Woche planen“-Funktion
- Familiengröße + Budget
- Vegan / Vegetarisch / Alle
- maximale Kochzeit
- Priorität: günstig, schnell, Meal Prep, kinderfreundlich
- Ausschlüsse / Kinder mögen nicht
- Vorratskammer
- Wochenplan
- Rezeptbibliothek
- Favoriten
- Rezeptdetailseiten
- Meal-Prep- und Einfrier-Kennzeichnung
- Angebote je Händler (Demo-Daten)
- offizielle Angebotslinks
- automatische Einkaufsliste
- Sortierung nach Warengruppen
- Vorräte werden von der Einkaufsliste abgezogen
- Checkboxen + Fortschrittsanzeige
- Budget- und Kostenschätzung
- lokale Speicherung im Browser

## Veröffentlichung
Die Datei `index.html` und `manifest.webmanifest` können direkt in dein GitHub-Pages-Repository hochgeladen werden.

## Wichtig
Die Live-Angebotsautomatisierung ist als Produktfunktion vorgesehen, aber die enthaltenen Angebotsdaten sind Demo-Daten. Für echte Live-Angebote müssen zulässige APIs/Feeds oder andere freigegebene Datenquellen pro Händler angeschlossen werden.


## V6 Premium-Erweiterungen
- lokale Rezeptbilder für alle Gerichte
- Bilder in Rezeptkarten und Rezeptdetails
- Überrasche-mich-Funktion
- Reste-verwerten-Funktion
- Letzte-Woche-Aktion
- Supermarkt-Modus
- Wochenrückblick
- Angebotsalarm-Platzhalter für spätere Live-Anbindung

## V7 Smart Planner
- Smart Planner mit Zielen: ausgewogen, maximal sparen, Vorräte zuerst, maximale Abwechslung
- Berücksichtigung von Budget, Vorräten, Zutaten-Wiederverwendung und Profil
- Smart-Plan-Analyse mit Kosten, Budgetrest, Vorratsnutzung und Zutatenanzahl
- Familienbewertungen für Rezepte
- Wiederherstellung des vorherigen Wochenplans
- Angebot → passendes Rezept
- Budgetwarnung


## V8 Rezept-Fix
- Rezeptbibliothek zeigt wieder alle 12 Gerichte direkt
- Suchfeld und Filter funktionieren unabhängig von Profilfiltern
- „Alle Rezepte anzeigen“-Reset
- Rezeptanzahl sichtbar
- Rezeptbilder direkt aus dem GitHub-Hauptverzeichnis
- größere Rezeptkarten und „Rezept öffnen“-Button


## V9 Rezeptbilder
- 12 appetitliche Rezeptfotos passend zu den Rezeptkarten
- Bilder werden direkt aus `images/*.jpg` geladen
- Rezeptübersicht und Rezeptdetails verwenden dieselben Fotos
